import { motion } from 'motion/react';
import { ArrowRight, Wrench } from 'lucide-react';

export default function Lineup() {
  return (
    <section className="max-w-container-max mx-auto px-margin py-32 border-t border-border-subtle">
      <div className="flex justify-between items-end mb-24 pb-6">
        <h2 className="text-6xl md:text-8xl font-black uppercase tracking-tighter font-display leading-[0.85]">
          THE<br/>LINEUP
        </h2>
        <div className="hidden md:flex gap-12">
          <span className="micro-label text-on-surface border-b border-on-surface pb-1 cursor-pointer">ALL MODELS</span>
          <span className="micro-label text-on-surface/40 hover:text-on-surface cursor-pointer transition-colors">SUPERSPORT</span>
          <span className="micro-label text-on-surface/40 hover:text-on-surface cursor-pointer transition-colors">PERFORMANCE SUV</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter">
        {/* Card 1: APEX PHANTOM R */}
        <motion.div 
          whileHover={{ y: -5 }}
          className="lg:col-span-8 bg-surface-container border-t border-l border-border-subtle group overflow-hidden relative min-h-[550px] flex flex-col justify-end"
        >
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuC6pWQMdDDUE8jLmiqZMRZGDAFGPrHFDx2AWHi7DacUcaXvZjH1a9Cz5e7dtAtrXqVjroNXf5gIGog8UcByTxSpxIZkvx-2dI3-7qbH2t45Y5Vi8J6bzqH--e5iLzFNktDCKs2hers28_Ik3LtKKBfnYKO_Si6UxV6w9vduSIyfjhjyCbUfEihDqk4uzYp-hXivQ60cStC1HwU6OQ_jF_HyVEzvtPCvvVkbhPzeUsTroGImMPBmx_cshCID3DgOslRdWlT4AMVLDIg" 
            className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale group-hover:opacity-60 group-hover:grayscale-0 transition-all duration-1000"
            alt="APEX PHANTOM R"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent" />
          <div className="relative z-10 p-12 flex flex-col md:flex-row justify-between items-end gap-8">
            <div>
              <span className="micro-label opacity-50 mb-4 block">Track Focused — Series R</span>
              <h3 className="text-4xl font-black mb-4 uppercase tracking-tight font-display">APEX PHANTOM R</h3>
              <div className="flex gap-10 micro-label opacity-60">
                <div>0-60 <span className="text-on-surface ml-2">2.6S</span></div>
                <div>TOP SPEED <span className="text-on-surface ml-2">205 MPH</span></div>
              </div>
            </div>
            <button className="btn-theme-outline bg-surface/40 backdrop-blur-sm">
              VIEW DETAILS
            </button>
          </div>
        </motion.div>

        {/* Card 2: APEX TITAN */}
        <motion.div 
          whileHover={{ y: -5 }}
          className="lg:col-span-4 bg-surface-container border-t border-l border-border-subtle group overflow-hidden relative min-h-[550px] flex flex-col justify-end"
        >
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuAnCXTrZ2MHbqWig84unLoqwHcNxOJJEbQ9cFoIQ3y3qCntdKBmMF_prcmFyNPr5016HAnqapvcFd_jd9Os_gJi8WChMOBDLUOhU27oCOBdYg_hG3zM862eIy3muloQkxAXo1vKZxVAiuEsfzz3fc6t7Mozus0YOc05j85oxPdxzIj6lAl_uc-6fyGsHzEgaJd6mh9Jo-Ycq4Fied4Wtf_uLoGVw_pRIhDedKwbWg6vpEuFkAMcRVp9xiVmq2MH13ZJXc4MDkka6EI" 
            className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale group-hover:opacity-60 group-hover:grayscale-0 transition-all duration-1000"
            alt="APEX TITAN"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-transparent to-transparent" />
          <div className="relative z-10 p-12">
            <span className="micro-label opacity-50 mb-4 block">Performance SUV</span>
            <h3 className="text-4xl font-black mb-8 uppercase tracking-tight font-display">APEX TITAN</h3>
            <div className="space-y-4 mb-10">
              <div className="flex justify-between border-b border-border-subtle pb-2">
                <span className="micro-label opacity-40">0-60 MPH</span>
                <span className="font-bold font-display italic">3.1S</span>
              </div>
              <div className="flex justify-between border-b border-border-subtle pb-2">
                <span className="micro-label opacity-40">TOP SPEED</span>
                <span className="font-bold font-display italic">190 MPH</span>
              </div>
            </div>
            <button className="w-full btn-theme-outline bg-surface/40 backdrop-blur-sm">
              VIEW DETAILS
            </button>
          </div>
        </motion.div>

        {/* Card 3: APEX AURA */}
        <div className="lg:col-span-4 bg-surface-container border-t border-l border-border-subtle group overflow-hidden relative min-h-[450px] flex flex-col justify-end p-10">
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDFqa-Y2qrw7IoDDRyT5h2atvVsnNA-H-vyJEJ4UXqusS2Ze42q94rjGDIi_23vYVZIDnxmVXqVNTuSoXHQtzeGQunbJsCjCR_LWStS5wfUdr1901crbGYqwnIRsb8S0F3jvu5WfDeZTCoHfC1mszopmNJvbFvbrqPVVjn4NEqjnApBECn6gyHUvZgYSnlc0WSSWr1r0_10aMgKvwEjkN_cmUATUK6GtSe5lsF_orRXmqDxi5LHCRvQ5zqtZHMWRys6eZhPTe7baXU" 
            className="absolute inset-0 w-full h-full object-cover opacity-20 filter grayscale"
            alt="APEX AURA"
          />
          <div className="relative z-10">
            <h3 className="text-3xl font-black mb-2 uppercase font-display">APEX AURA</h3>
            <p className="font-light opacity-60 mb-6">Pure electric grand tourer.</p>
            <button className="micro-label flex items-center gap-4 hover:gap-6 transition-all">
              EXPLORE <ArrowRight size={14} />
            </button>
          </div>
        </div>

        {/* Card 4: APEX NOVA */}
        <div className="lg:col-span-4 bg-surface-container border-t border-l border-border-subtle group overflow-hidden relative min-h-[450px] flex flex-col justify-end p-10">
          <img 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDxiBNz6ZZA5-TSFFNtVuxzcF2LogRbuGHwkVCbxDEPCvpm-9pEfobQl0A3o-9LY00qofh-GvRvQl2jn4nIbvWwkNrsBSjOx82803WwKocwAphVXXEDx7JaoyIhkRRpnWEnPoG7QCIydXmfA-S3ADNMLUFtLAcXrpwtvKUCQJnwZOjrFhrZhI36hgBAEiPTe5SVGuT2-PsTwMnH-RF4X9h3Qs7nTBQHX8jYbj2cw-9Y1UlSTdDJ02rnhnx5RcRlcq73DPGomoDEq5g" 
            className="absolute inset-0 w-full h-full object-cover opacity-20 filter grayscale"
            alt="APEX NOVA"
          />
          <div className="relative z-10">
            <h3 className="text-3xl font-black mb-2 uppercase font-display">APEX NOVA</h3>
            <p className="font-light opacity-60 mb-6">Agile, lightweight precision.</p>
            <button className="micro-label flex items-center gap-4 hover:gap-6 transition-all">
              EXPLORE <ArrowRight size={14} />
            </button>
          </div>
        </div>

        {/* Card 5: BESPOKE PROGRAM */}
        <div className="lg:col-span-4 bg-surface-container-high border-t border-l border-border-subtle p-12 flex flex-col items-start justify-center">
          <div className="w-12 h-1 bg-on-surface opacity-20 mb-8" />
          <h3 className="text-3xl font-black mb-4 uppercase font-display tracking-tighter">BESPOKE PROGRAM</h3>
          <p className="font-light opacity-60 mb-10">
            Commission a uniquely tailored vehicle through our private customization studio.
          </p>
          <button className="btn-theme-primary">
            INQUIRE
          </button>
        </div>
      </div>
    </section>
  );
}
