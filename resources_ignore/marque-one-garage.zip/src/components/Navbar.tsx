import { motion } from 'motion/react';
import { User, Globe } from 'lucide-react';

export default function Navbar() {
  const navLinks = [
    { name: 'Models', active: true },
    { name: 'Configurator', active: false },
    { name: 'Heritage', active: false },
    { name: 'Racing', active: false },
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 w-full z-50 px-margin py-8 border-b border-border-subtle bg-surface/80 backdrop-blur-md"
    >
      <div className="max-w-container-max mx-auto flex justify-between items-start">
        <div className="flex flex-col">
          <span className="text-[10px] font-bold tracking-[0.3em] uppercase opacity-50 font-display">Performance Edition</span>
          <span className="text-2xl font-black tracking-tighter text-white uppercase font-display leading-tight">
            MARQUE™
          </span>
        </div>

        <div className="hidden md:flex gap-12 items-center pt-2">
          {navLinks.map((link) => (
            <a 
              key={link.name}
              href="#" 
              className={`micro-label transition-all duration-300 hover:text-white ${
                link.active 
                  ? 'text-on-surface' 
                  : 'text-on-surface-variant'
              }`}
            >
              {link.name}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-8">
          <button className="hidden lg:block micro-label text-on-surface opacity-80 hover:opacity-100 transition-opacity">
            REQUEST TEST DRIVE
          </button>
          <div className="flex gap-5 text-on-surface-variant">
            <User size={18} className="cursor-pointer hover:text-white transition-colors" />
            <Globe size={18} className="cursor-pointer hover:text-white transition-colors" />
          </div>
        </div>
      </div>
    </motion.nav>
  );
}
