export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-surface py-20 px-margin border-t border-border-subtle">
      <div className="max-w-container-max mx-auto flex flex-col md:flex-row justify-between items-end gap-16">
        <div className="flex flex-col gap-2">
          <span className="text-xl font-black tracking-tighter text-white uppercase font-display leading-tight">
            MARQUE™
          </span>
          <span className="micro-label opacity-40">Precision Engineering</span>
        </div>

        <div className="flex-grow grid grid-cols-2 md:grid-cols-4 gap-12 md:gap-24">
          <div className="flex flex-col gap-2">
            <span className="text-[9px] font-bold tracking-[0.1em] uppercase opacity-40 font-display">Inquiries</span>
            <span className="text-xs font-medium underline cursor-pointer hover:text-white transition-colors decoration-border-subtle hover:decoration-on-surface">sales@marque.one</span>
          </div>
          <div className="flex flex-col gap-2">
            <span className="text-[9px] font-bold tracking-[0.1em] uppercase opacity-40 font-display">Status</span>
            <span className="text-xs font-medium italic opacity-80">Online Configurator v2.4</span>
          </div>
          <div className="flex flex-col gap-2">
            <span className="text-[9px] font-bold tracking-[0.1em] uppercase opacity-40 font-display">Dealer Network</span>
            <span className="text-xs font-medium opacity-80 cursor-pointer hover:text-white transition-all">Berlin, DE</span>
          </div>
          <div className="flex flex-col gap-2">
            <span className="text-[9px] font-bold tracking-[0.1em] uppercase opacity-40 font-display">Legal</span>
            <span className="text-xs font-medium opacity-80 cursor-pointer hover:text-white transition-all">Privacy / Terms</span>
          </div>
        </div>

        <div className="flex items-center gap-5">
          <div className="w-3 h-3 bg-on-surface rounded-full animate-pulse"></div>
          <div className="flex flex-col items-end">
            <span className="micro-label opacity-60">System Operational</span>
            <span className="text-[9px] opacity-20 uppercase font-black font-display mt-1">© {currentYear} MARQUE™</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
