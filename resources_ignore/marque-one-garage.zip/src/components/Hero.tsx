import { motion } from 'motion/react';

export default function Hero() {
  const specs = [
    { label: '0-60 MPH', value: '2.4', unit: 'SEC', progress: '90%' },
    { label: 'TOP SPEED', value: '218', unit: 'MPH', progress: '85%' },
    { label: 'HORSEPOWER', value: '1,050', unit: 'HP', progress: '95%' },
  ];

  return (
    <section className="relative h-screen w-full flex items-end pb-32 overflow-hidden">
      {/* Background Image - Exactly as requested */}
      <div className="absolute inset-0 -z-10">
        <img 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuAa-_SySjAFnpcCEmYKqr2L8N6nj9JGPEgrDQA4_UD-D9M17KiMMAInZOiuHHiDmXDEMI6kpN_I0wJSSEKfja2aQmlx6KDueF51jlH4-Ut745ONZRfh7bjfzxP_Jdnmcksejen4v62mDPYf-A_X6uCMc_VpAjrWQrwdENZaCk3JaQv1etUswC3QSoJJLQe3-G1drj_24oxTuipRkqDYF2dAn9MGsDeque3GWAYlR2-k4WUDGh975QTfKhjQv9MFQLSvbWGJQtSudA0"
          className="w-full h-full object-cover"
          alt="APEX SENTINEL"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
      </div>

      <div className="relative z-10 w-full max-w-container-max mx-auto px-margin flex flex-col md:flex-row justify-between items-end gap-12">
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-xl"
        >
          <div className="flex gap-3 mb-6">
            <span className="bg-surface-container-high/80 backdrop-blur-sm text-on-surface-variant px-3 py-1 micro-label border-l border-brand-accent-red">
              V12 HYBRID
            </span>
            <span className="bg-surface-container-high/80 backdrop-blur-sm text-on-surface-variant px-3 py-1 micro-label border-l border-brand-accent-red">
              AERODYNAMIC ACTIVE
            </span>
          </div>
          
          <h1 className="text-[64px] md:text-[80px] font-black leading-[1] mb-6 uppercase tracking-tight font-display text-white">
            APEX SENTINEL
          </h1>
          
          <p className="text-body-md text-on-surface-variant mb-10 max-w-lg leading-relaxed">
            The pinnacle of hybrid performance engineering. Combining raw mechanical power with hyper-intelligent torque vectoring for an unprecedented driving experience.
          </p>

          <div className="flex gap-5">
            <button className="btn-hero-solid">
              BUILD YOURS
            </button>
            <button className="btn-hero-outline bg-black/20 backdrop-blur-sm">
              VIEW SPECS
            </button>
          </div>
        </motion.div>

        {/* Specs Widget - Dark translucent rectangle as in image */}
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="hidden lg:flex flex-col gap-8 bg-[#0a0a0a]/80 backdrop-blur-lg p-10 border-t border-l border-white/5 w-[320px] performance-metric-glow"
        >
          {specs.map((spec) => (
            <div key={spec.label}>
              <div className="text-[10px] font-bold tracking-widest text-on-surface-variant uppercase mb-2">{spec.label}</div>
              <div className="text-3xl font-black text-brand-accent-red flex items-baseline gap-1">
                {spec.value}
                <span className="text-[11px] font-bold text-on-surface opacity-60">{spec.unit}</span>
              </div>
              <div className="h-[2px] bg-white/10 mt-3 overflow-hidden rounded-full">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: spec.progress }}
                  transition={{ duration: 1.5, delay: 0.8, ease: "easeOut" }}
                  className="h-full bg-brand-accent-red" 
                />
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Slide Indicators as in image */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
        <div className="w-12 h-[2px] bg-brand-accent-red" />
        <div className="w-12 h-[2px] bg-white/20" />
        <div className="w-12 h-[2px] bg-white/20" />
      </div>
    </section>
  );
}
